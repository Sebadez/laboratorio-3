/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cronometrot;

import java.util.Date;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;


public class Timeropps {
 
   long miliseconds=1;
   long reps=1;
   int r=0;
   int at=0;
   String O;
   String N;
   public void conv(){
      
   
       Scanner a= new Scanner(System.in);
       Scanner b= new Scanner(System.in);
       Scanner cinn= new Scanner(System.in);
       Scanner t= new Scanner(System.in);
     
  
       System.out.print("INGRESE EN CUANTO TIEMPO DESEA GENERAR LA ALARMA -> (H,M,S) :");
   
       O= a.nextLine();
      switch(O){
          case "H":{
            System.out.print("INGRESE EL TIEMPO :");
         
            at = cinn.nextInt();
          
            miliseconds= at*360000;
              break;
          }
          case "M":{
                      
            System.out.print("INGRESE EL TIEMPO :");
          
            at = cinn.nextInt();
            
            miliseconds= at*60000;
              break;
          }
          case "S":{
            System.out.print("INGRESE EL TIEMPO :");
       
            at = cinn.nextInt();
       
            miliseconds= at*1000;
              break;
          }
      }
     

       System.out.print("INGRESE CADA CUANTO TIEMPO DESEA QUE SE REPTITA LA ALARMA -> (H,M,S) :");
     
       N= b.nextLine();
      switch(N){
           
          case "H":{
        
            System.out.print("INGRESE EL TIEMPO :");
  
      
             r = t.nextInt();
          
            reps= r*360000;
          }
          case "M":{
            System.out.print("INGRESE EL TIEMPO :");
   

            r = t.nextInt();
         
            reps= r*60000;
          }
          case "S":{
            System.out.print("INGRESE EL TIEMPO :");
   
            r = t.nextInt();
         
            reps= r*1000;
          }
          
      }
      
   }
    Timer crono = new Timer();
    TimerTask duty=new TimerTask() {
       @Override
       public void run() {
           System.out.println("Alarma sonando a las  "+ new Date());
       }
    };
    public void sh(){
        crono.schedule(duty, miliseconds, reps);
    }
}