/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cronometrot;


public class CronometroT {

   public static void main(String[] args) {
   Timeropps p1= new Timeropps();
   p1.conv();
   p1.sh();

}   
}
   
